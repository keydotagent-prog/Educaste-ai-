import Anthropic from "@anthropic-ai/sdk";
import { auth } from "@clerk/nextjs/server";
import { NextResponse } from "next/server";

const client = new Anthropic({
  apiKey: process.env.ANTHROPIC_API_KEY!,
});

export async function POST(req: Request) {
  try {
    const { userId } = auth();
    if (!userId) {
      return NextResponse.json(
        { error: "Unauthorized" },
        { status: 401 }
      );
    }

    const { content, title } = await req.json();

    if (!content || !title) {
      return NextResponse.json(
        { error: "Title and content are required" },
        { status: 400 }
      );
    }

    const message = await client.messages.create({
      model: "claude-opus-4-5",
      max_tokens: 4000,
      messages: [
        {
          role: "user",
          content: `You are an expert educational content creator who transforms boring textbook content into hilarious, engaging video scripts for students.

Transform this textbook content into a funny, engaging video script:

TITLE: ${title}
CONTENT: ${content}

Rules:
- Make it funny and engaging for students
- Add jokes, memes references and storytelling
- Break it into short scenes (30-60 seconds each)
- Keep educational value while being entertaining
- Use simple language students understand

Return ONLY a valid JSON object, no extra text, no markdown:
{
  "title": "catchy video title",
  "hook": "opening line to grab attention in first 3 seconds",
  "scenes": [
    {
      "scene_number": 1,
      "duration": "30 seconds",
      "narration": "exactly what the narrator says",
      "visual_description": "what appears on screen",
      "joke_or_story": "funny element or story beat",
      "key_concept": "the educational concept being taught"
    }
  ],
  "outro": "closing line that makes students want more",
  "total_duration": "estimated total video length"
}`,
        },
      ],
    });

    const text =
      message.content[0].type === "text"
        ? message.content[0].text
        : "";

    // Clean response and parse JSON
    const cleaned = text
      .replace(/```json/g, "")
      .replace(/```/g, "")
      .trim();

    const script = JSON.parse(cleaned);

    return NextResponse.json({ script });
  } catch (error: any) {
    console.error("Script generation error:", error);
    return NextResponse.json(
      { error: error.message || "Failed to generate script" },
      { status: 500 }
    );
  }
}