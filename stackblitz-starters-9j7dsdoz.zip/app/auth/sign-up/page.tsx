import { SignUp } from "@clerk/nextjs";

export default function SignUpPage() {
  return (
      <main className="min-h-screen bg-white flex flex-col items-center
          justify-center py-12 px-4">
                <div className="mb-8 text-center">
                        <span className="text-4xl">🎓</span>
                                <h1 className="text-2xl font-black text-gray-900 mt-2">
                                          Join <span className="text-yellow-400">Educaste AI</span>
                                                  </h1>
                                                          <p className="text-gray-500 text-sm mt-1">
                                                                    Start transforming education today
                                                                            </p>
                                                                                  </div>
                                                                                        <SignUp />
                                                                                            </main>
                                                                                              );
                                                                                              }