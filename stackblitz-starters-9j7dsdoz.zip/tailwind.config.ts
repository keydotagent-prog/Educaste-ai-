import type { Config } from "tailwindcss";

const config: Config = {
  content: [
      "./pages/**/*.{js,ts,jsx,tsx,mdx}",
          "./components/**/*.{js,ts,jsx,tsx,mdx}",
              "./app/**/*.{js,ts,jsx,tsx,mdx}",
                ],
                  theme: {
                      extend: {
                            colors: {
                                    primary: {
                                              DEFAULT: "#F5C518",
                                                        hover: "#D97706",
                                                                  light: "#FEF9C3",
                                                                          },
                                                                                  accent: {
                                                                                            DEFAULT: "#F59E0B",
                                                                                                      dark: "#D97706",
                                                                                                              },
                                                                                                                      surface: {
                                                                                                                                DEFAULT: "#FFFBEB",
                                                                                                                                          card: "#FFFFFF",
                                                                                                                                                  },
                                                                                                                                                          dark: {
                                                                                                                                                                    DEFAULT: "#111111",
                                                                                                                                                                              muted: "#6B7280",
                                                                                                                                                                                      },
                                                                                                                                                                                            },
                                                                                                                                                                                                  fontFamily: {
                                                                                                                                                                                                          sans: ["Inter", "sans-serif"],
                                                                                                                                                                                                                },
                                                                                                                                                                                                                      boxShadow: {
                                                                                                                                                                                                                              yellow: "0 4px 24px 0 rgba(245,197,24,0.25)",
                                                                                                                                                                                                                                      card: "0 2px 16px 0 rgba(0,0,0,0.08)",
                                                                                                                                                                                                                                            },
                                                                                                                                                                                                                                                  backgroundImage: {
                                                                                                                                                                                                                                                          "hero-gradient":
                                                                                                                                                                                                                                                                    "linear-gradient(135deg, #FEF9C3 0%, #FFFBEB 50%, #FFFFFF 100%)",
                                                                                                                                                                                                                                                                            "yellow-gradient":
                                                                                                                                                                                                                                                                                      "linear-gradient(135deg, #F5C518 0%, #F59E0B 100%)",
                                                                                                                                                                                                                                                                                            },
                                                                                                                                                                                                                                                                                                },
                                                                                                                                                                                                                                                                                                  },
                                                                                                                                                                                                                                                                                                    plugins: [],
                                                                                                                                                                                                                                                                                                    };

                                                                                                                                                                                                                                                                                                    export default config;
