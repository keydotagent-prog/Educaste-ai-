import { createClient } from "@supabase/supabase-js";

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!;
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!;
const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY!;

// Client for frontend
export const supabase = createClient(supabaseUrl, supabaseAnonKey);

// Client for backend (API routes)
export const supabaseAdmin = createClient(supabaseUrl, supabaseServiceKey);

export type Project = {
  id: string;
    user_id: string;
      title: string;
        original_content: string;
          generated_script: any;
            video_url: string | null;
              status: "draft" | "script_ready" | "video_ready";
                created_at: string;
                  updated_at: string;
                  };