import { auth } from "@clerk/nextjs/server";
import { NextResponse } from "next/server";

export async function POST(req: Request) {
  try {
    const { userId } = auth();
    if (!userId) {
      return NextResponse.json(
        { error: "Unauthorized" },
        { status: 401 }
      );
    }

    const { sceneDescription, narration } = await req.json();

    if (!sceneDescription || !narration) {
      return NextResponse.json(
        { error: "Scene description and narration are required" },
        { status: 400 }
      );
    }

    // Step 1: Create video generation task
    const createRes = await fetch(
      "https://api.dev.runwayml.com/v1/image_to_video",
      {
        method: "POST",
        headers: {
          Authorization: `Bearer ${process.env.RUNWAY_API_KEY}`,
          "Content-Type": "application/json",
          "X-Runway-Version": "2024-11-06",
        },
        body: JSON.stringify({
          model: "gen4_turbo",
          promptText: `${sceneDescription}. ${narration}. Educational animation style, bright colors, engaging visuals for students.`,
          duration: 10,
          ratio: "1280:720",
        }),
      }
    );

    const task = await createRes.json();

    if (!task.id) {
      return NextResponse.json(
        { error: "Failed to create video task" },
        { status: 500 }
      );
    }

    // Step 2: Poll until video is ready
    let videoUrl = null;
    let attempts = 0;
    const maxAttempts = 30;

    while (!videoUrl && attempts < maxAttempts) {
      // Wait 5 seconds between polls
      await new Promise((r) => setTimeout(r, 5000));

      const pollRes = await fetch(
        `https://api.dev.runwayml.com/v1/tasks/${task.id}`,
        {
          headers: {
            Authorization: `Bearer ${process.env.RUNWAY_API_KEY}`,
            "X-Runway-Version": "2024-11-06",
          },
        }
      );

      const status = await pollRes.json();

      if (status.status === "SUCCEEDED") {
        videoUrl = status.output?.[0];
        break;
      }

      if (status.status === "FAILED") {
        return NextResponse.json(
          { error: "Video generation failed" },
          { status: 500 }
        );
      }

      attempts++;
    }

    if (!videoUrl) {
      return NextResponse.json(
        { error: "Video generation timed out. Please try again." },
        { status: 504 }
      );
    }

    return NextResponse.json({ videoUrl });
  } catch (error: any) {
    console.error("Video generation error:", error);
    return NextResponse.json(
      { error: error.message || "Failed to generate video" },
      { status: 500 }
    );
  }
}