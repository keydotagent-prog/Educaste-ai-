import { auth } from "@clerk/nextjs/server";
import { NextResponse } from "next/server";
import { supabaseAdmin } from "@/lib/supabase";

export async function POST(req: Request) {
  try {
    const { userId } = auth();
    if (!userId) {
      return NextResponse.json(
        { error: "Unauthorized" },
        { status: 401 }
      );
    }

    const body = await req.json();

    const {
      title,
      originalContent,
      script,
      videoUrl,
      status,
      projectId,
    } = body;

    if (!title || !originalContent) {
      return NextResponse.json(
        { error: "Title and content are required" },
        { status: 400 }
      );
    }

    const payload = {
      user_id: userId,
      title,
      original_content: originalContent,
      generated_script: script ?? null,
      video_url: videoUrl ?? null,
      status: status ?? "draft",
      updated_at: new Date().toISOString(),
    };

    let data;

    if (projectId) {
      // Update existing project
      const { data: updated, error } = await supabaseAdmin
        .from("projects")
        .update(payload)
        .eq("id", projectId)
        .eq("user_id", userId)
        .select()
        .single();

      if (error) throw error;
      data = updated;
    } else {
      // Create new project
      const { data: created, error } = await supabaseAdmin
        .from("projects")
        .insert(payload)
        .select()
        .single();

      if (error) throw error;
      data = created;
    }

    return NextResponse.json({ project: data });
  } catch (error: any) {
    console.error("Save project error:", error);
    return NextResponse.json(
      { error: error.message || "Failed to save project" },
      { status: 500 }
    );
  }
}

export async function GET(req: Request) {
  try {
    const { userId } = auth();
    if (!userId) {
      return NextResponse.json(
        { error: "Unauthorized" },
        { status: 401 }
      );
    }

    const { data, error } = await supabaseAdmin
      .from("projects")
      .select("*")
      .eq("user_id", userId)
      .order("updated_at", { ascending: false });

    if (error) throw error;

    return NextResponse.json({ projects: data });
  } catch (error: any) {
    console.error("Fetch projects error:", error);
    return NextResponse.json(
      { error: error.message || "Failed to fetch projects" },
      { status: 500 }
    );
  }
}