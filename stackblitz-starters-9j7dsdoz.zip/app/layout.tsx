import type { Metadata } from "next";
import { Inter } from "next/font/google";
import { ClerkProvider } from "@clerk/nextjs";
import "./globals.css";

const inter = Inter({ subsets: ["latin"] });

export const metadata: Metadata = {
  title: "Educaste AI",
    description: "Transform boring textbook content into fun, engaging video scripts powered by AI",
    };

    export default function RootLayout({
      children,
      }: {
        children: React.ReactNode;
        }) {
          return (
              <ClerkProvider
                    appearance={{
                            variables: {
                                      colorPrimary: "#F5C518",
                                                colorText: "#111111",
                                                          colorBackground: "#FFFFFF",
                                                                    colorInputBackground: "#FFFBEB",
                                                                              colorInputText: "#111111",
                                                                                      },
                                                                                            }}
                                                                                                >
                                                                                                      <html lang="en">
                                                                                                              <body className={`${inter.className} bg-white text-dark`}>
                                                                                                                        {children}
                                                                                                                                </body>
                                                                                                                                      </html>
                                                                                                                                          </ClerkProvider>
                                                                                                                                            );
                                                                                                                                            }
