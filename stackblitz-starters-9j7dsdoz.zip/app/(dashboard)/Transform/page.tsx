"use client";

import { useState, useEffect } from "react";
import { useUser } from "@clerk/nextjs";
import { useRouter, useSearchParams } from "next/navigation";
import Link from "next/link";
import { supabase } from "@/lib/supabase";

export default function TransformPage() {
  const { user } = useUser();
  const router = useRouter();
  const searchParams = useSearchParams();
  const projectId = searchParams.get("id");

  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const [script, setScript] = useState<any>(null);
  const [videoUrls, setVideoUrls] = useState<Record<number, string>>({});
  const [loadingScript, setLoadingScript] = useState(false);
  const [loadingVideo, setLoadingVideo] = useState<number | null>(null);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const [projectDbId, setProjectDbId] = useState<string | null>(null);

  // Load existing project
  useEffect(() => {
    if (projectId) {
      loadProject(projectId);
    }
  }, [projectId]);

  async function loadProject(id: string) {
    const { data } = await supabase
      .from("projects")
      .select("*")
      .eq("id", id)
      .single();
    if (data) {
      setTitle(data.title);
      setContent(data.original_content);
      setScript(data.generated_script);
      setProjectDbId(data.id);
    }
  }

  async function handleGenerateScript() {
    if (!title.trim() || !content.trim()) {
      setError("Please enter a title and content!");
      return;
    }
    setError("");
    setLoadingScript(true);
    setScript(null);

    try {
      const res = await fetch("/api/generate-script", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ title, content }),
      });
      const data = await res.json();
      if (data.error) throw new Error(data.error);
      setScript(data.script);
      await saveProject(data.script, null, "script_ready");
    } catch (err: any) {
      setError(err.message || "Failed to generate script. Try again!");
    } finally {
      setLoadingScript(false);
    }
  }

  async function handleGenerateVideo(scene: any, index: number) {
    setLoadingVideo(index);
    try {
      const res = await fetch("/api/generate-video", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          sceneDescription: scene.visual_description,
          narration: scene.narration,
        }),
      });
      const data = await res.json();
      if (data.error) throw new Error(data.error);
      const updated = { ...videoUrls, [index]: data.videoUrl };
      setVideoUrls(updated);
    } catch (err: any) {
      setError(err.message || "Failed to generate video.");
    } finally {
      setLoadingVideo(null);
    }
  }

  async function saveProject(
    scriptData: any,
    videoUrl: string | null,
    status: string
  ) {
    if (!user) return;
    setSaving(true);
    try {
      const payload = {
        user_id: user.id,
        title,
        original_content: content,
        generated_script: scriptData,
        video_url: videoUrl,
        status,
        updated_at: new Date().toISOString(),
      };

      if (projectDbId) {
        await supabase
          .from("projects")
          .update(payload)
          .eq("id", projectDbId);
      } else {
        const { data } = await supabase
          .from("projects")
          .insert(payload)
          .select()
          .single();
        if (data) setProjectDbId(data.id);
      }
    } finally {
      setSaving(false);
    }
  }

  return (
    <main className="min-h-screen bg-white">
      {/* Navbar */}
      <nav className="flex items-center justify-between px-6 py-4
      border-b border-yellow-100">
        <div className="flex items-center gap-2">
          <span className="text-2xl">🎓</span>
          <span className="font-black text-xl text-gray-900">
            Educaste <span className="text-yellow-400">AI</span>
          </span>
        </div>
        <div className="flex items-center gap-4">
          <Link
            href="/dashboard"
            className="text-sm font-semibold text-gray-600
            hover:text-yellow-500 transition"
          >
            ← Dashboard
          </Link>
          <Link
            href="/history"
            className="text-sm font-semibold text-gray-600
            hover:text-yellow-500 transition"
          >
            History
          </Link>
        </div>
      </nav>

      <div className="container-main py-10">
        <div className="mb-8">
          <h1 className="text-3xl font-black text-gray-900">
            Transform Content ✨
          </h1>
          <p className="text-gray-500 mt-1">
            Paste your textbook content and watch the magic happen!
          </p>
        </div>

        {/* Input Section */}
        <div className="card mb-6">
          <label className="block text-sm font-bold text-gray-700 mb-2">
            Project Title
          </label>
          <input
            type="text"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="e.g. Photosynthesis Chapter 3"
            className="w-full border-2 border-yellow-200 rounded-xl px-4 py-3
            text-gray-900 font-medium focus:outline-none focus:border-yellow-400
            transition mb-4"
          />

          <label className="block text-sm font-bold text-gray-700 mb-2">
            Textbook Content
          </label>
          <textarea
            value={content}
            onChange={(e) => setContent(e.target.value)}
            placeholder="Paste your textbook content here..."
            rows={6}
            className="w-full border-2 border-yellow-200 rounded-xl px-4 py-3
            text-gray-900 focus:outline-none focus:border-yellow-400
            transition resize-none"
          />

          {error && (
            <div className="mt-3 bg-red-50 border border-red-200 text-red-600
            text-sm px-4 py-3 rounded-xl">
              ⚠️ {error}
            </div>
          )}

          <button
            onClick={handleGenerateScript}
            disabled={loadingScript}
            className="mt-4 w-full bg-yellow-400 hover:bg-yellow-500
            disabled:opacity-50 text-gray-900 font-black text-lg py-4
            rounded-2xl transition shadow-yellow"
          >
            {loadingScript ? (
              <span className="flex items-center justify-center gap-2">
                <span className="animate-spin">⚙️</span>
                Generating Script...
              </span>
            ) : (
              "✨ Generate Script"
            )}
          </button>

          {saving && (
            <p className="text-center text-xs text-gray-400 mt-2">
              💾 Saving...
            </p>
          )}
        </div>

        {/* Script Output */}
        {script && (
          <div className="animate-fadeInUp">
            {/* Script Header */}
            <div className="card mb-4 bg-yellow-50 border-yellow-200">
              <h2 className="text-xl font-black text-gray-900 mb-1">
                🎬 {script.title}
              </h2>
              <p className="text-gray-600 text-sm mb-2">
                <span className="font-bold">Hook:</span> {script.hook}
              </p>
              <p className="text-gray-500 text-xs">
                ⏱ {script.total_duration}
              </p>
            </div>

            {/* Scenes */}
            <h3 className="text-lg font-black text-gray-900 mb-4">
              📽️ Scenes
            </h3>
            <div className="flex flex-col gap-4 mb-6">
              {script.scenes?.map((scene: any, i: number) => (
                <div key={i} className="card border-l-4 border-yellow-400">
                  <div className="flex items-center justify-between mb-3">
                    <span className="bg-yellow-400 text-gray-900 font-black
                    text-xs px-3 py-1 rounded-full">
                      Scene {scene.scene_number}
                    </span>
                    <span className="text-xs text-gray-400">
                      ⏱ {scene.duration}
                    </span>
                  </div>

                  <div className="space-y-2 mb-4">
                    <div>
                      <span className="text-xs font-bold text-yellow-600
                      uppercase">
                        🎤 Narration
                      </span>
                      <p className="text-gray-700 text-sm mt-1">
                        {scene.narration}
                      </p>
                    </div>
                    <div>
                      <span className="text-xs font-bold text-yellow-600
                      uppercase">
                        🎭 Visual
                      </span>
                      <p className="text-gray-700 text-sm mt-1">
                        {scene.visual_description}
                      </p>
                    </div>
                    <div>
                      <span className="text-xs font-bold text-yellow-600
                      uppercase">
                        😂 Joke / Story
                      </span>
                      <p className="text-gray-700 text-sm mt-1">
                        {scene.joke_or_story}
                      </p>
                    </div>
                    <div>
                      <span className="text-xs font-bold text-yellow-600
                      uppercase">
                        🧠 Key Concept
                      </span>
                      <p className="text-gray-700 text-sm mt-1">
                        {scene.key_concept}
                      </p>
                    </div>
                  </div>

                  {/* Video section */}
                  {videoUrls[i] ? (
                    <video
                      src={videoUrls[i]}
                      controls
                      className="w-full rounded-xl mt-2"
                    />
                  ) : (
                    <button
                      onClick={() => handleGenerateVideo(scene, i)}
                      disabled={loadingVideo === i}
                      className="w-full bg-gray-900 hover:bg-gray-800
                      disabled:opacity-50 text-yellow-400 font-bold py-3
                      rounded-xl transition text-sm"
                    >
                      {loadingVideo === i ? (
                        <span className="flex items-center justify-center gap-2">
                          <span className="animate-spin">⚙️</span>
                          Generating Video...
                        </span>
                      ) : (
                        "🎬 Generate Video for this Scene"
                      )}
                    </button>
                  )}
                </div>
              ))}
            </div>

            {/* Outro */}
            <div className="card bg-yellow-50 border-yellow-200 text-center">
              <p className="text-gray-600 font-medium">
                🎤 <span className="font-bold">Outro:</span> {script.outro}
              </p>
            </div>
          </div>
        )}
      </div>
    </main>
  );
}