import { auth } from "@clerk/nextjs/server";
import { redirect } from "next/navigation";
import Link from "next/link";
import { UserButton } from "@clerk/nextjs";
import { supabaseAdmin } from "@/lib/supabase";

export default async function HistoryPage() {
  const { userId } = auth();
  if (!userId) redirect("/sign-in");

  const { data: projects } = await supabaseAdmin
    .from("projects")
    .select("*")
    .eq("user_id", userId)
    .order("updated_at", { ascending: false });

  return (
    <main className="min-h-screen bg-white">
      {/* Navbar */}
      <nav className="flex items-center justify-between px-6 py-4
      border-b border-yellow-100">
        <div className="flex items-center gap-2">
          <span className="text-2xl">🎓</span>
          <span className="font-black text-xl text-gray-900">
            Educaste <span className="text-yellow-400">AI</span>
          </span>
        </div>
        <div className="flex items-center gap-4">
          <Link
            href="/dashboard"
            className="text-sm font-semibold text-gray-600
            hover:text-yellow-500 transition"
          >
            ← Dashboard
          </Link>
          <Link
            href="/transform"
            className="bg-yellow-400 hover:bg-yellow-500 text-gray-900
            font-bold text-sm px-4 py-2 rounded-xl transition"
          >
            + New Project
          </Link>
          <UserButton afterSignOutUrl="/" />
        </div>
      </nav>

      <div className="container-main py-10">
        <div className="mb-8">
          <h1 className="text-3xl font-black text-gray-900">
            Your History 📚
          </h1>
          <p className="text-gray-500 mt-1">
            All your past projects in one place
          </p>
        </div>

        {projects && projects.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {projects.map((project) => (
              <div
                key={project.id}
                className="card hover:-translate-y-1
                transition-transform duration-200"
              >
                <div className="flex items-start justify-between mb-3">
                  <h3 className="font-bold text-gray-900 text-lg">
                    {project.title}
                  </h3>
                  <span
                    className={`text-xs font-bold px-3 py-1 rounded-full
                    whitespace-nowrap ml-2 ${
                      project.status === "video_ready"
                        ? "bg-green-100 text-green-700"
                        : project.status === "script_ready"
                        ? "bg-yellow-100 text-yellow-700"
                        : "bg-gray-100 text-gray-500"
                    }`}
                  >
                    {project.status === "video_ready"
                      ? "🎬 Video Ready"
                      : project.status === "script_ready"
                      ? "📝 Script Ready"
                      : "📁 Draft"}
                  </span>
                </div>

                <p className="text-gray-500 text-sm line-clamp-2 mb-4">
                  {project.original_content}
                </p>

                <div className="flex items-center justify-between
                border-t border-yellow-100 pt-3">
                  <div className="text-xs text-gray-400">
                    <span>Created: </span>
                    {new Date(project.created_at).toLocaleDateString()}
                  </div>
                  <div className="text-xs text-gray-400">
                    <span>Updated: </span>
                    {new Date(project.updated_at).toLocaleDateString()}
                  </div>
                  <Link
                    href={`/transform?id=${project.id}`}
                    className="text-sm font-bold text-yellow-500
                    hover:text-yellow-600 transition"
                  >
                    Open →
                  </Link>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="card text-center py-16">
            <div className="text-5xl mb-4">📭</div>
            <h3 className="font-black text-xl text-gray-900 mb-2">
              No projects yet!
            </h3>
            <p className="text-gray-500 mb-6">
              Start transforming content and your history will appear here.
            </p>
            <Link
              href="/transform"
              className="bg-yellow-400 hover:bg-yellow-500 text-gray-900
              font-black px-8 py-3 rounded-2xl transition inline-block"
            >
              Create First Project 🚀
            </Link>
          </div>
        )}
      </div>
    </main>
  );
}